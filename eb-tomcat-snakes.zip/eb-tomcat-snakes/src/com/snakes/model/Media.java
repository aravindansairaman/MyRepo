package com.snakes.model;

public abstract class Media {

}
